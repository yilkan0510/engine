//
// Created by yilka on 3/22/2024.
//

#ifndef ENGINE_LSYSTEM3DGENERATOR_H
#define ENGINE_LSYSTEM3DGENERATOR_H


class LSystem3DGenerator {

};


#endif //ENGINE_LSYSTEM3DGENERATOR_H
